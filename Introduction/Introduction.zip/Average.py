first = float(input('First= '))
second = float(input('Second= '))
third = float(input('Third= '))
mean = (first + second + third)/3
print('mean = (first + second + third)/3= ',mean)