first = 14585
second = 75498
summa = first + second
diff = first - second
print(summa, diff)